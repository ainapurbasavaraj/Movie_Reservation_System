--
-- PostgreSQL database dump
--

-- Dumped from database version 14.9 (Ubuntu 14.9-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.9 (Ubuntu 14.9-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.booking_table DROP CONSTRAINT fk_userid;
ALTER TABLE ONLY public.login_session DROP CONSTRAINT fk_userid;
ALTER TABLE ONLY public.show_details DROP CONSTRAINT fk_theaterid;
ALTER TABLE ONLY public.booking_table DROP CONSTRAINT fk_show_id;
ALTER TABLE ONLY public.show_table DROP CONSTRAINT fk_show_id;
ALTER TABLE ONLY public.show_details DROP CONSTRAINT fk_movieid;
ALTER TABLE ONLY public.movie_table DROP CONSTRAINT fk_locationid;
ALTER TABLE ONLY public.theatre_table DROP CONSTRAINT fk_locationid;
ALTER TABLE ONLY public.ticketing_table DROP CONSTRAINT fk_booking_id;
ALTER TABLE ONLY public.user_info DROP CONSTRAINT user_info_username_key;
ALTER TABLE ONLY public.user_info DROP CONSTRAINT user_info_pkey;
ALTER TABLE ONLY public.user_info DROP CONSTRAINT user_info_phone_key;
ALTER TABLE ONLY public.user_info DROP CONSTRAINT user_info_emailid_key;
ALTER TABLE ONLY public.ticketing_table DROP CONSTRAINT ticketing_table_pkey;
ALTER TABLE ONLY public.theatre_table DROP CONSTRAINT theatre_table_pkey;
ALTER TABLE ONLY public.show_table DROP CONSTRAINT show_table_pkey;
ALTER TABLE ONLY public.show_details DROP CONSTRAINT show_details_pkey;
ALTER TABLE ONLY public.movie_table DROP CONSTRAINT movie_table_pkey;
ALTER TABLE ONLY public.login_session DROP CONSTRAINT login_session_pkey;
ALTER TABLE ONLY public.login_session DROP CONSTRAINT login_session_accetoken_key;
ALTER TABLE ONLY public.location_table DROP CONSTRAINT location_table_pkey;
ALTER TABLE ONLY public.location_table DROP CONSTRAINT location_table_locationname_key;
ALTER TABLE ONLY public.booking_table DROP CONSTRAINT booking_table_pkey;
DROP TABLE public.user_info;
DROP TABLE public.ticketing_table;
DROP TABLE public.theatre_table;
DROP TABLE public.show_table;
DROP TABLE public.show_details;
DROP TABLE public.movie_table;
DROP TABLE public.login_session;
DROP TABLE public.location_table;
DROP TABLE public.booking_table;
DROP TYPE public.theatre_type;
DROP TYPE public.payment_status;
--
-- Name: payment_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.payment_status AS ENUM (
    'SUCCESS',
    'FAILURE',
    'PENDING'
);


ALTER TYPE public.payment_status OWNER TO postgres;

--
-- Name: theatre_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.theatre_type AS ENUM (
    'PVR',
    'INOX',
    'IMAX'
);


ALTER TYPE public.theatre_type OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: booking_table; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.booking_table (
    booking_id character varying(80) NOT NULL,
    userid character varying(80) NOT NULL,
    show_id character varying(80) NOT NULL,
    booked_seats integer NOT NULL,
    payment_status public.payment_status NOT NULL
);


ALTER TABLE public.booking_table OWNER TO postgres;

--
-- Name: location_table; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.location_table (
    locationid character varying(80) NOT NULL,
    locationname character varying(80) NOT NULL
);


ALTER TABLE public.location_table OWNER TO postgres;

--
-- Name: login_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.login_session (
    userid character varying(80) NOT NULL,
    accetoken character varying(80) NOT NULL,
    refreshtime timestamp without time zone
);


ALTER TABLE public.login_session OWNER TO postgres;

--
-- Name: movie_table; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.movie_table (
    movieid character varying(80) NOT NULL,
    moviename character varying(80) NOT NULL,
    locationid character varying(80)
);


ALTER TABLE public.movie_table OWNER TO postgres;

--
-- Name: show_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.show_details (
    show_id character varying(80) NOT NULL,
    theaterid character varying(80) NOT NULL,
    movieid character varying(80) NOT NULL,
    showdate date,
    showtime time without time zone
);


ALTER TABLE public.show_details OWNER TO postgres;

--
-- Name: show_table; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.show_table (
    show_id character varying(80) NOT NULL,
    total_seats integer NOT NULL,
    available_seats integer NOT NULL,
    amount integer NOT NULL,
    currency character varying(10)
);


ALTER TABLE public.show_table OWNER TO postgres;

--
-- Name: theatre_table; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.theatre_table (
    theaterid character varying(80) NOT NULL,
    theatrename character varying(80) NOT NULL,
    theatretype public.theatre_type,
    address character varying(80),
    locationid character varying(80)
);


ALTER TABLE public.theatre_table OWNER TO postgres;

--
-- Name: ticketing_table; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ticketing_table (
    ticket_id character varying(80) NOT NULL,
    booking_id character varying(80) NOT NULL,
    ticket_url character varying(80)
);


ALTER TABLE public.ticketing_table OWNER TO postgres;

--
-- Name: user_info; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_info (
    userid character varying(80) NOT NULL,
    username character varying(80) NOT NULL,
    emailid character varying(80) NOT NULL,
    password character varying(80) NOT NULL,
    phone character varying(80) NOT NULL
);


ALTER TABLE public.user_info OWNER TO postgres;

--
-- Data for Name: booking_table; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: location_table; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: login_session; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: movie_table; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: show_details; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: show_table; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: theatre_table; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: ticketing_table; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: user_info; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.user_info VALUES ('1', 'girish', 'aaa@gmail.com', 'qwerty', '9123456789');
INSERT INTO public.user_info VALUES ('2', 'chidu', 'chidu@gmail.com', 'welcome', '9122334455');


--
-- Name: booking_table booking_table_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.booking_table
    ADD CONSTRAINT booking_table_pkey PRIMARY KEY (booking_id);


--
-- Name: location_table location_table_locationname_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.location_table
    ADD CONSTRAINT location_table_locationname_key UNIQUE (locationname);


--
-- Name: location_table location_table_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.location_table
    ADD CONSTRAINT location_table_pkey PRIMARY KEY (locationid);


--
-- Name: login_session login_session_accetoken_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login_session
    ADD CONSTRAINT login_session_accetoken_key UNIQUE (accetoken);


--
-- Name: login_session login_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login_session
    ADD CONSTRAINT login_session_pkey PRIMARY KEY (userid);


--
-- Name: movie_table movie_table_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movie_table
    ADD CONSTRAINT movie_table_pkey PRIMARY KEY (movieid);


--
-- Name: show_details show_details_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.show_details
    ADD CONSTRAINT show_details_pkey PRIMARY KEY (show_id);


--
-- Name: show_table show_table_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.show_table
    ADD CONSTRAINT show_table_pkey PRIMARY KEY (show_id);


--
-- Name: theatre_table theatre_table_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.theatre_table
    ADD CONSTRAINT theatre_table_pkey PRIMARY KEY (theaterid);


--
-- Name: ticketing_table ticketing_table_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticketing_table
    ADD CONSTRAINT ticketing_table_pkey PRIMARY KEY (ticket_id);


--
-- Name: user_info user_info_emailid_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_info
    ADD CONSTRAINT user_info_emailid_key UNIQUE (emailid);


--
-- Name: user_info user_info_phone_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_info
    ADD CONSTRAINT user_info_phone_key UNIQUE (phone);


--
-- Name: user_info user_info_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_info
    ADD CONSTRAINT user_info_pkey PRIMARY KEY (userid);


--
-- Name: user_info user_info_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_info
    ADD CONSTRAINT user_info_username_key UNIQUE (username);


--
-- Name: ticketing_table fk_booking_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticketing_table
    ADD CONSTRAINT fk_booking_id FOREIGN KEY (booking_id) REFERENCES public.booking_table(booking_id);


--
-- Name: theatre_table fk_locationid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.theatre_table
    ADD CONSTRAINT fk_locationid FOREIGN KEY (locationid) REFERENCES public.location_table(locationid);


--
-- Name: movie_table fk_locationid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movie_table
    ADD CONSTRAINT fk_locationid FOREIGN KEY (locationid) REFERENCES public.location_table(locationid);


--
-- Name: show_details fk_movieid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.show_details
    ADD CONSTRAINT fk_movieid FOREIGN KEY (movieid) REFERENCES public.movie_table(movieid);


--
-- Name: show_table fk_show_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.show_table
    ADD CONSTRAINT fk_show_id FOREIGN KEY (show_id) REFERENCES public.show_details(show_id);


--
-- Name: booking_table fk_show_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.booking_table
    ADD CONSTRAINT fk_show_id FOREIGN KEY (show_id) REFERENCES public.show_details(show_id);


--
-- Name: show_details fk_theaterid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.show_details
    ADD CONSTRAINT fk_theaterid FOREIGN KEY (theaterid) REFERENCES public.theatre_table(theaterid);


--
-- Name: login_session fk_userid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login_session
    ADD CONSTRAINT fk_userid FOREIGN KEY (userid) REFERENCES public.user_info(userid);


--
-- Name: booking_table fk_userid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.booking_table
    ADD CONSTRAINT fk_userid FOREIGN KEY (userid) REFERENCES public.user_info(userid);


--
-- PostgreSQL database dump complete
--


import psycopg2

# Connect to your postgres DB
#conn = psycopg2.connect("dbname=postgres user=postgres host=/var/lib/postgresql")
#conn = psycopg2.connect("dbname=postgres user=postgres host=/tmp/")
conn = psycopg2.connect("dbname=postgres user=postgres password=welcome")
#conn = psycopg2.connect("dbname=postgres user=postgres host=/var/run/postgresql password=welcome")

# Open a cursor to perform database operations
cur = conn.cursor()

# Execute a query
cur.execute("SELECT * FROM user_info")

# Retrieve query results
records = cur.fetchall()

print(records)
